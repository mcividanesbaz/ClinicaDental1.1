from distutils.core import setup
"""
Esta clase se ha creado para generar el targz o el .exe de windows, pero lo que he conseguido generar ha sido la carpeta build con un script
"""
setup(name="Clinica Dental",
      version="0.1",
      description="software para la gestion de una clinica dental",
      author="Marcos Cividanes",
      author_email="mcividanes",
      url="http://mundogeek.net/tutorial-python/",
      license="GPL",
      scripts=["setup.py"],
      py_modules=["Metodos"]
)